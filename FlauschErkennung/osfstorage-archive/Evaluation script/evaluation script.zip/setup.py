import setuptools

with open("README.md", "r", encoding="utf-8") as fhand:
    long_description = fhand.read()

setuptools.setup(
    name="flauscheval",
    version="0.1",
    author="Tatjana Scheffler",
    author_email="tatjana.scheffler@rub.de",
    description=("Simple evaluation scripts for sequence "
                "tagging (binary and fine-grained) used in candy speech shared task."),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://yuliacl.github.io/GermEval2025-Flausch-Erkennung",
    project_urls={
        "Shared Task": "https://yuliacl.github.io/GermEval2025-Flausch-Erkennung",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=["pandas","scikit-learn","multiset"],
    packages=setuptools.find_packages(),
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "flauscheval = flauscheval.cli:main",
        ]
    }
)
