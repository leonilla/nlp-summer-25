# Simple evaluation scripts for the candy speech detection shared task 2025

Author: Tatjana Scheffler

URL of the task: https://yuliacl.github.io/GermEval2025-Flausch-Erkennung

## Prerequisites

```
pip install .
```

## Task 1: Binary evaluation

```
flauscheval -t FINE gold-file predicted-file
```

## Task 2: Fine-grained Evaluation

```
flauscheval -t BINARY gold-file predicted-file
```