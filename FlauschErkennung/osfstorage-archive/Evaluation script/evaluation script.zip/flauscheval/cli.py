"""
The command-line interface for the evaluation scripts
"""
import argparse
from .flauscheval import binary_eval,fine_grained_flausch_by_label


def main():
    parser = argparse.ArgumentParser(
        description="Simple evaluation scripts for sequence tagging (binary and fine-grained) used in candy speech shared task."
    )
    parser.add_argument(
        "file_gold", type=str,
        help="The file path of the gold annotation file."
    )
    parser.add_argument(
        "file_pred", type=str,
        help="The file path of the predicted annotation file."
    )
    parser.add_argument(
        "--task", "-t",
        help=("The evaluation task (BINARY or FINE/f). Default=BINARY.")
    )
    args = parser.parse_args()
    if args.task == 'FINE' or args.task == 'f':
        # fine-grained task
        results = fine_grained_flausch_by_label(args.file_gold,args.file_pred)
        print("TASK 2: FINE GRAINED CLASSIFICATION",
            "\n===================================",
            "\nPrecision:\t %.4f" % results['TOTAL']['STRICT']['prec'],
            "\nRecall:\t\t %.4f" % results['TOTAL']['STRICT']['rec'],
            "\nF-score:\t %.4f" % results['TOTAL']['STRICT']['f1'])
    else:
        (bin_prec, bin_rec, bin_f) = binary_eval(args.file_gold,args.file_pred)
        print("TASK 1: BINARY CLASSIFICATION",
            "\n=============================",
            "\nPrecision:\t %.4f" % bin_prec,
            "\nRecall:\t\t %.4f" % bin_rec,
            "\nF-score:\t %.4f" % bin_f)


if __name__ == "__main__":
    main()
